// يُستبدل تلقائيًا أثناء النشر من أسرار المستودع (SUPABASE_URL / SUPABASE_ANON_KEY)
window.SITE_CONFIG = {
  url: "__SUPABASE_URL__",
  key: "__SUPABASE_ANON_KEY__",
  showPrices: true,      // إظهار أسعار التجزئة والجملة في الموقع
  pageSize: 24
};
