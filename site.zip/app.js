/* EL MAKIN — الموقع العام + المتجر. يقرأ من Supabase عبر Views عامة آمنة (بدون أسعار الشراء). */
const CFG = window.SITE_CONFIG;

const WILAYAS = {
  ar: ["أدرار", "الشلف", "الأغواط", "أم البواقي", "باتنة", "بجاية", "بسكرة", "بشار", "البليدة", "البويرة", "تمنراست", "تبسة", "تلمسان", "تيارت", "تيزي وزو", "الجزائر", "الجلفة", "جيجل", "سطيف", "سعيدة", "سكيكدة", "سيدي بلعباس", "عنابة", "قالمة", "قسنطينة", "المدية", "مستغانم", "المسيلة", "معسكر", "ورقلة", "وهران", "البيض", "إليزي", "برج بوعريريج", "بومرداس", "الطارف", "تندوف", "تيسمسيلت", "الوادي", "خنشلة", "سوق أهراس", "تيبازة", "ميلة", "عين الدفلى", "النعامة", "عين تموشنت", "غرداية", "غليزان", "تيميمون", "برج باجي مختار", "أولاد جلال", "بني عباس", "عين صالح", "عين قزام", "تقرت", "جانت", "المغير", "المنيعة"],
  fr: ["Adrar", "Chlef", "Laghouat", "Oum El Bouaghi", "Batna", "Béjaïa", "Biskra", "Béchar", "Blida", "Bouira", "Tamanrasset", "Tébessa", "Tlemcen", "Tiaret", "Tizi Ouzou", "Alger", "Djelfa", "Jijel", "Sétif", "Saïda", "Skikda", "Sidi Bel Abbès", "Annaba", "Guelma", "Constantine", "Médéa", "Mostaganem", "M'Sila", "Mascara", "Ouargla", "Oran", "El Bayadh", "Illizi", "Bordj Bou Arréridj", "Boumerdès", "El Tarf", "Tindouf", "Tissemsilt", "El Oued", "Khenchela", "Souk Ahras", "Tipaza", "Mila", "Aïn Defla", "Naâma", "Aïn Témouchent", "Ghardaïa", "Relizane", "Timimoun", "Bordj Badji Mokhtar", "Ouled Djellal", "Béni Abbès", "In Salah", "In Guezzam", "Touggourt", "Djanet", "El M'Ghair", "El Meniaa"]
};

const T = {
  ar: {
    home:'الرئيسية', products:'المنتجات', categories:'الأقسام', about:'من نحن', contact:'اتصل بنا', login:'دخول', track:'تتبع الطلب',
    hero_sub:'أدوات مدرسية وهدايا بالجملة والتجزئة بأفضل الأسعار.',
    browse:'تصفح المنتجات', latest:'أحدث المنتجات', all:'الكل', search:'ابحث باسم المنتج...',
    retail:'تجزئة', wholesale:'جملة', in_stock:'متوفر', out_stock:'غير متوفر', load_more:'عرض المزيد',
    no_results:'لا توجد نتائج', error:'تعذر تحميل البيانات',
    about_title:'من نحن',
    about_text:'EL MAKIN محل متخصص في بيع الأدوات المدرسية والهدايا بالجملة والتجزئة. نوفر لزبائننا منتجات متنوعة بأسعار منافسة وخدمة سريعة، مع إمكانية الشحن لمختلف الولايات.',
    contact_title:'تواصل معنا', name:'الاسم', phone:'الهاتف', message:'رسالتك', send:'إرسال',
    sent:'تم إرسال رسالتك. سنتواصل معك قريبًا.', fill:'يرجى ملء الاسم والرسالة.',
    login_title:'تسجيل الدخول', email:'البريد الإلكتروني', password:'كلمة المرور', signin:'دخول', signout:'تسجيل الخروج',
    logged_in:'تم تسجيل الدخول بنجاح.', bad_login:'البريد أو كلمة المرور غير صحيحة.',
    store_soon:'موظفو المحل يستخدمون تطبيق EL MAKIN. يمكنك طلب منتجاتك مباشرة من هذا الموقع بدون حساب.',
    rights:'جميع الحقوق محفوظة', lang:'Français', address:'العنوان', tel:'الهاتف',
    add_cart:'أضف إلى السلة', added:'تمت الإضافة إلى السلة',
    cart_title:'سلة الطلبات', cart_empty:'السلة فارغة', total:'الإجمالي', qty:'الكمية', remove:'حذف',
    order_info:'معلومات التوصيل', full_name:'الاسم الكامل', wilaya:'الولاية', choose:'اختر...', addr:'العنوان',
    center:'مركز الشحن (مكتب التوصيل)', note:'ملاحظة (اختياري)', place_order:'تأكيد الطلب',
    order_done:'تم استلام طلبك!', order_no:'رقم الطلب', keep_no:'احتفظ برقم الطلب ورقم هاتفك لتتبع الطلب.',
    pay_note:'الدفع عند الاستلام. سنتصل بك لتأكيد الطلب وتكلفة الشحن.',
    send_wa:'أرسل الطلب عبر واتساب', go_track:'تتبع الطلب', phone_bad:'رقم الهاتف غير صحيح.',
    track_title:'تتبع الطلب', track_btn:'بحث', track_none:'لم نجد طلبًا بهذه البيانات.',
    st_new:'قيد المراجعة', st_confirmed:'مؤكد', st_shipped:'تم الشحن', st_delivered:'تم التسليم', st_cancelled:'ملغى',
    wa:'واتساب', ms:'ماسنجر', sending:'جارٍ الإرسال...', prices_note:'الأسعار بالدينار الجزائري (DZD). سعر التجزئة للطلبات عبر الموقع.'
  },
  fr: {
    home:'Accueil', products:'Produits', categories:'Catégories', about:'À propos', contact:'Contact', login:'Connexion', track:'Suivi de commande',
    hero_sub:'Fournitures scolaires et cadeaux en gros et au détail, aux meilleurs prix.',
    browse:'Voir les produits', latest:'Nouveautés', all:'Tout', search:'Rechercher un produit...',
    retail:'Détail', wholesale:'Gros', in_stock:'En stock', out_stock:'Rupture', load_more:'Voir plus',
    no_results:'Aucun résultat', error:'Impossible de charger les données',
    about_title:'À propos',
    about_text:"EL MAKIN est spécialisé dans la vente de fournitures scolaires et de cadeaux en gros et au détail. Nous proposons un large choix de produits à prix compétitifs et un service rapide, avec expédition vers toutes les wilayas.",
    contact_title:'Contactez-nous', name:'Nom', phone:'Téléphone', message:'Votre message', send:'Envoyer',
    sent:'Message envoyé. Nous vous répondrons bientôt.', fill:'Veuillez remplir le nom et le message.',
    login_title:'Connexion', email:'E-mail', password:'Mot de passe', signin:'Se connecter', signout:'Se déconnecter',
    logged_in:'Connexion réussie.', bad_login:'E-mail ou mot de passe incorrect.',
    store_soon:"Le personnel utilise l'application EL MAKIN. Vous pouvez commander directement sur ce site sans compte.",
    rights:'Tous droits réservés', lang:'العربية', address:'Adresse', tel:'Téléphone',
    add_cart:'Ajouter au panier', added:'Ajouté au panier',
    cart_title:'Panier', cart_empty:'Le panier est vide', total:'Total', qty:'Quantité', remove:'Supprimer',
    order_info:'Informations de livraison', full_name:'Nom complet', wilaya:'Wilaya', choose:'Choisir...', addr:'Adresse',
    center:"Centre d'expédition (bureau de livraison)", note:'Remarque (facultatif)', place_order:'Confirmer la commande',
    order_done:'Commande reçue !', order_no:'N° de commande', keep_no:'Conservez le numéro de commande et votre téléphone pour suivre la commande.',
    pay_note:'Paiement à la livraison. Nous vous appellerons pour confirmer la commande et les frais de livraison.',
    send_wa:'Envoyer la commande par WhatsApp', go_track:'Suivre la commande', phone_bad:'Numéro de téléphone invalide.',
    track_title:'Suivi de commande', track_btn:'Rechercher', track_none:'Aucune commande trouvée avec ces informations.',
    st_new:'En cours de vérification', st_confirmed:'Confirmée', st_shipped:'Expédiée', st_delivered:'Livrée', st_cancelled:'Annulée',
    wa:'WhatsApp', ms:'Messenger', sending:'Envoi...', prices_note:'Prix en dinars algériens (DZD). Prix de détail pour les commandes en ligne.'
  }
};

let lang = localStorage.getItem('lang') || 'ar';
const t = k => (T[lang] && T[lang][k]) || k;
const $ = (s, el = document) => el.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money = n => new Intl.NumberFormat('fr-DZ', {maximumFractionDigits: 2}).format(Number(n || 0)) + ' DZD';
const pname = p => (lang === 'fr' && p.name_fr) ? p.name_fr : p.name_ar;
const cname = c => (lang === 'fr' && c.name_fr) ? c.name_fr : c.name_ar;

let session = null;
try { session = JSON.parse(localStorage.getItem('session') || 'null'); } catch (_) {}

async function api(path, opts = {}) {
  const { anon, ...rest } = opts;
  const send = token => fetch(CFG.url + path, {
    ...rest,
    headers: { apikey: CFG.key, Authorization: 'Bearer ' + token, ...(rest.headers || {}) }
  });
  let res = await send(!anon && session && session.access_token ? session.access_token : CFG.key);
  if (res.status === 401 && !anon) { // جلسة منتهية: نمسحها ونعيد المحاولة كزائر
    session = null; localStorage.removeItem('session');
    res = await send(CFG.key);
  }
  if (!res.ok) {
    let detail = '';
    try { const j = await res.json(); detail = j.message || j.error_description || ''; } catch (_) {}
    throw new Error(detail || ('HTTP ' + res.status));
  }
  return res.status === 204 ? null : res.json();
}

const rpc = (name, body) => api('/rest/v1/rpc/' + name, {
  anon: true, method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(body)
});

let shop = { shop_name: 'EL MAKIN', phone: '', address: '', whatsapp: '', messenger: '', contact_email: '' };
async function loadShop() {
  try { (await api('/rest/v1/public_shop?select=key,value')).forEach(r => shop[r.key] = r.value); } catch (_) {}
}

/* إشعار على البريد (Gmail) عبر FormSubmit — يعمل بعد تفعيل البريد مرة واحدة */
async function notifyEmail(subject, fields) {
  if (!shop.contact_email) return;
  try {
    await fetch('https://formsubmit.co/ajax/' + encodeURIComponent(shop.contact_email), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({ _subject: subject, _template: 'table', _captcha: 'false', ...fields })
    });
  } catch (_) {}
}

const waLink = text => 'https://wa.me/' + String(shop.whatsapp || '').replace(/\D/g, '') + '?text=' + encodeURIComponent(text);

/* ---------- السلة ---------- */
const loadCart = () => { try { return JSON.parse(localStorage.getItem('cart') || '{}'); } catch (_) { return {}; } };
const saveCart = c => { localStorage.setItem('cart', JSON.stringify(c)); updateBadge(); };
const cartCount = () => Object.values(loadCart()).reduce((s, i) => s + i.qty, 0);
const cartTotal = () => Object.values(loadCart()).reduce((s, i) => s + i.qty * Number(i.price), 0);
function updateBadge() { const b = $('#cartCount'); if (b) b.textContent = cartCount(); }
window.__P = {};
function addToCart(id) {
  const p = window.__P[id]; if (!p) return;
  const c = loadCart();
  if (c[id]) c[id].qty += 1;
  else c[id] = { id, name_ar: p.name_ar, name_fr: p.name_fr, price: p.retail_price, qty: 1, image_url: p.image_url };
  saveCart(c);
  const toast = $('#toast'); if (toast) { toast.textContent = t('added'); toast.style.opacity = 1; setTimeout(() => toast.style.opacity = 0, 1200); }
}
document.addEventListener('click', e => {
  const b = e.target.closest('[data-add]'); if (b && !b.disabled) addToCart(b.dataset.add);
});

const PAGES = [
  ['index.html', 'home'], ['products.html', 'products'], ['categories.html', 'categories'],
  ['about.html', 'about'], ['contact.html', 'contact'], ['track.html', 'track'], ['login.html', 'login']
];

function renderShell() {
  const page = document.body.dataset.page;
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  $('#hdr').innerHTML = `
    <header class="site"><div class="bar">
      <a class="brand" href="index.html">EL MAKIN</a>
      <nav class="main">${PAGES.map(([f, k]) =>
        `<a href="${f}" class="${page === k ? 'active' : ''}">${t(k)}</a>`).join('')}
        <a href="cart.html" class="cart-link ${page === 'cart' ? 'active' : ''}">🛒<b id="cartCount">0</b></a></nav>
      <button class="lang-btn" id="langBtn">${t('lang')}</button>
    </div></header>
    <div id="toast" style="position:fixed;top:70px;inset-inline-end:16px;background:#14213d;color:#fff;padding:8px 16px;border-radius:10px;opacity:0;transition:opacity .3s;z-index:30"></div>`;
  const wa = shop.whatsapp ? `<a class="wa" href="${waLink('')}" target="_blank" rel="noopener" title="${t('wa')}">💬</a>` : '';
  const ms = shop.messenger ? `<a class="ms" href="https://m.me/${encodeURIComponent(shop.messenger)}" target="_blank" rel="noopener" title="${t('ms')}">✉️</a>` : '';
  $('#ftr').innerHTML = `
    <footer class="site"><div class="container">
      <strong>${esc(shop.shop_name || 'EL MAKIN')}</strong>
      ${shop.phone ? `<div>${t('tel')}: <a href="tel:${esc(shop.phone)}">${esc(shop.phone)}</a></div>` : ''}
      ${shop.address ? `<div>${t('address')}: ${esc(shop.address)}</div>` : ''}
      <div class="muted">© ${new Date().getFullYear()} EL MAKIN — ${t('rights')}</div>
    </div></footer>
    ${(wa || ms) ? `<div class="float">${wa}${ms}</div>` : ''}`;
  $('#langBtn').onclick = () => { lang = lang === 'ar' ? 'fr' : 'ar'; localStorage.setItem('lang', lang); boot(); };
  updateBadge();
}

function productCard(p) {
  window.__P[p.id] = p;
  const img = p.image_url ? `<img loading="lazy" src="${esc(p.image_url)}" alt="">` : '🎁';
  const prices = CFG.showPrices ? `
    <div class="price">${t('retail')}: ${money(p.retail_price)}</div>
    ${Number(p.wholesale_price) > 0 ? `<div class="muted">${t('wholesale')}: ${money(p.wholesale_price)}</div>` : ''}` : '';
  return `<div class="card"><div class="img">${img}</div><div class="body">
    <h3>${esc(pname(p))}</h3>${prices}
    <span class="badge ${p.in_stock ? 'ok' : 'out'}">${p.in_stock ? t('in_stock') : t('out_stock')}</span>
    <button class="btn primary block" data-add="${esc(p.id)}" ${p.in_stock ? '' : 'disabled'}>${t('add_cart')}</button>
  </div></div>`;
}

/* ---------- الصفحات ---------- */
async function pageHome() {
  const [cats, prods] = await Promise.all([
    api('/rest/v1/public_categories?select=*&order=name_ar.asc&limit=12'),
    api('/rest/v1/public_products?select=*&order=name_ar.asc&limit=8')
  ]);
  $('#heroSub').textContent = t('hero_sub');
  $('#heroName').textContent = shop.shop_name || 'EL MAKIN';
  $('#cats').innerHTML = cats.map(c => `<a class="chip" href="products.html?cat=${c.id}">${esc(cname(c))}</a>`).join('');
  $('#latest').innerHTML = prods.length ? prods.map(productCard).join('') : `<div class="empty">${t('no_results')}</div>`;
}

async function pageProducts() {
  const params = new URLSearchParams(location.search);
  let cat = params.get('cat') || '', q = params.get('q') || '', offset = 0;
  const cats = await api('/rest/v1/public_categories?select=*&order=name_ar.asc');
  const chips = $('#chips'), grid = $('#grid'), more = $('#more'), search = $('#search');
  search.placeholder = t('search'); search.value = q;

  const drawChips = () => {
    chips.innerHTML = `<span class="chip ${!cat ? 'active' : ''}" data-id="">${t('all')}</span>` +
      cats.map(c => `<span class="chip ${cat === c.id ? 'active' : ''}" data-id="${c.id}">${esc(cname(c))}</span>`).join('');
    chips.querySelectorAll('.chip').forEach(el => el.onclick = () => { cat = el.dataset.id; reload(); });
  };

  async function load(reset) {
    if (reset) { offset = 0; grid.innerHTML = ''; }
    let url = `/rest/v1/public_products?select=*&order=name_ar.asc&limit=${CFG.pageSize}&offset=${offset}`;
    if (cat) url += `&category_id=eq.${encodeURIComponent(cat)}`;
    const s = q.trim().replace(/[,()*%]/g, '');
    if (s) url += `&or=(name_ar.ilike.*${encodeURIComponent(s)}*,name_fr.ilike.*${encodeURIComponent(s)}*)`;
    const rows = await api(url);
    grid.insertAdjacentHTML('beforeend', rows.map(productCard).join(''));
    if (reset && !rows.length) grid.innerHTML = `<div class="empty">${t('no_results')}</div>`;
    offset += rows.length;
    more.style.display = rows.length === CFG.pageSize ? 'inline-block' : 'none';
  }
  const reload = () => { drawChips(); return load(true); };
  more.textContent = t('load_more'); more.onclick = () => load(false);
  let timer; search.oninput = () => { clearTimeout(timer); timer = setTimeout(() => { q = search.value; load(true); }, 350); };
  drawChips(); await load(true);
}

async function pageCategories() {
  const cats = await api('/rest/v1/public_categories?select=*&order=name_ar.asc');
  $('#catGrid').innerHTML = cats.length
    ? cats.map(c => `<a class="card" href="products.html?cat=${c.id}"><div class="body"><h3>📁 ${esc(cname(c))}</h3></div></a>`).join('')
    : `<div class="empty">${t('no_results')}</div>`;
}

function pageAbout() { $('#aboutText').textContent = t('about_text'); }

function pageContact() {
  const form = $('#contactForm'), msg = $('#msg');
  const el = n => form.elements[n];
  const acts = $('#contactActions');
  const links = [];
  if (shop.whatsapp) links.push(`<a class="btn" target="_blank" rel="noopener" href="${waLink('')}">💬 ${t('wa')}</a>`);
  if (shop.messenger) links.push(`<a class="btn" target="_blank" rel="noopener" href="https://m.me/${encodeURIComponent(shop.messenger)}">✉️ ${t('ms')}</a>`);
  acts.innerHTML = links.join('');
  form.onsubmit = async e => {
    e.preventDefault();
    const name = el('name').value.trim(), phone = el('phone').value.trim(), message = el('message').value.trim();
    msg.className = 'msg';
    if (!name || !message) { msg.className = 'msg err'; msg.textContent = t('fill'); return; }
    try {
      await api('/rest/v1/contact_messages', {
        anon: true, method: 'POST',
        headers: { 'Content-Type': 'application/json', Prefer: 'return=minimal' },
        body: JSON.stringify({ name, phone: phone || null, message })
      });
      notifyEmail('رسالة جديدة من الموقع', { الاسم: name, الهاتف: phone, الرسالة: message });
      form.reset(); msg.className = 'msg ok'; msg.textContent = t('sent');
    } catch (err) { msg.className = 'msg err'; msg.textContent = t('error') + ' (' + err.message + ')'; }
  };
}

function pageLogin() {
  const form = $('#loginForm'), msg = $('#msg'), out = $('#signedIn');
  const draw = () => {
    form.style.display = session ? 'none' : 'block';
    out.style.display = session ? 'block' : 'none';
    if (session) $('#who').textContent = (session.user && session.user.email) || '';
  };
  form.onsubmit = async e => {
    e.preventDefault(); msg.className = 'msg';
    try {
      const res = await fetch(CFG.url + '/auth/v1/token?grant_type=password', {
        method: 'POST',
        headers: { apikey: CFG.key, 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: form.elements['email'].value.trim(), password: form.elements['password'].value })
      });
      if (!res.ok) throw new Error('bad');
      session = await res.json();
      localStorage.setItem('session', JSON.stringify(session));
      msg.className = 'msg ok'; msg.textContent = t('logged_in'); draw();
    } catch (_) { msg.className = 'msg err'; msg.textContent = t('bad_login'); }
  };
  $('#signout').onclick = () => { session = null; localStorage.removeItem('session'); msg.className = 'msg'; draw(); };
  draw();
}

/* ---------- السلة وإتمام الطلب ---------- */
function pageCart() {
  const listEl = $('#cartList'), totalEl = $('#cartTotal'), form = $('#orderForm'), done = $('#done'), msg = $('#msg');
  const el = n => form.elements[n];
  el('wilaya').innerHTML = `<option value="">${t('choose')}</option>` +
    WILAYAS[lang].map((w, i) => `<option value="${String(i + 1).padStart(2, '0')} - ${esc(w)}">${String(i + 1).padStart(2, '0')} - ${esc(w)}</option>`).join('');

  function draw() {
    const items = Object.values(loadCart());
    if (!items.length) {
      listEl.innerHTML = `<div class="empty">${t('cart_empty')}</div>`;
      form.style.display = 'none'; $('#totalBar').style.display = 'none'; return;
    }
    listEl.innerHTML = items.map(i => `
      <div class="cart-row">
        ${i.image_url ? `<img src="${esc(i.image_url)}" alt="">` : '<div class="ph">🎁</div>'}
        <div class="info"><strong>${esc(lang === 'fr' && i.name_fr ? i.name_fr : i.name_ar)}</strong>
          <div class="muted">${money(i.price)}</div></div>
        <div class="qty">
          <button data-act="dec" data-id="${esc(i.id)}">−</button><b>${i.qty}</b>
          <button data-act="inc" data-id="${esc(i.id)}">+</button>
        </div>
        <button class="chip" data-act="del" data-id="${esc(i.id)}">✕</button>
      </div>`).join('');
    $('#totalBar').style.display = 'flex';
    totalEl.textContent = money(cartTotal());
    form.style.display = 'block';
  }
  listEl.onclick = e => {
    const b = e.target.closest('[data-act]'); if (!b) return;
    const c = loadCart(), id = b.dataset.id; if (!c[id]) return;
    if (b.dataset.act === 'inc') c[id].qty += 1;
    else if (b.dataset.act === 'dec') c[id].qty = Math.max(1, c[id].qty - 1);
    else delete c[id];
    saveCart(c); draw();
  };

  form.onsubmit = async e => {
    e.preventDefault(); msg.className = 'msg';
    const phone = el('phone').value.trim();
    if (!/^[0-9+\s]{8,20}$/.test(phone)) { msg.className = 'msg err'; msg.textContent = t('phone_bad'); return; }
    const cart = loadCart();
    const items = Object.values(cart).map(i => ({ product_id: i.id, qty: i.qty }));
    const btn = form.querySelector('button[type=submit]'); btn.disabled = true; btn.textContent = t('sending');
    try {
      const r = await rpc('create_public_order', {
        p_name: el('name').value.trim(), p_phone: phone, p_wilaya: el('wilaya').value,
        p_address: el('address').value.trim(), p_center: el('center').value.trim(),
        p_note: el('note').value.trim(), p_items: items
      });
      const summary = Object.values(cart).map(i => `${i.qty} x ${i.name_ar}`).join('\n');
      const total = r.total;
      notifyEmail('طلب جديد ' + r.order_no, {
        'رقم الطلب': r.order_no, 'الاسم': el('name').value, 'الهاتف': phone, 'الولاية': el('wilaya').value,
        'العنوان': el('address').value, 'مركز الشحن': el('center').value, 'المنتجات': summary, 'الإجمالي': total
      });
      const waText = `${t('order_no')}: ${r.order_no}\n${summary}\n${t('total')}: ${money(total)}\n${el('name').value} - ${phone}`;
      localStorage.removeItem('cart'); updateBadge();
      form.style.display = 'none'; $('#totalBar').style.display = 'none'; listEl.innerHTML = '';
      done.style.display = 'block';
      done.innerHTML = `<h3>✅ ${t('order_done')}</h3>
        <p>${t('order_no')}: <strong>${esc(r.order_no)}</strong> — ${t('total')}: <strong>${money(total)}</strong></p>
        <p class="muted">${t('keep_no')}</p><p class="muted">${t('pay_note')}</p>
        <div class="actions">
          <a class="btn primary" href="track.html?no=${encodeURIComponent(r.order_no)}">${t('go_track')}</a>
          ${shop.whatsapp ? `<a class="btn" target="_blank" rel="noopener" href="${waLink(waText)}">💬 ${t('send_wa')}</a>` : ''}
        </div>`;
    } catch (err) {
      msg.className = 'msg err'; msg.textContent = t('error') + ' (' + err.message + ')';
      btn.disabled = false; btn.textContent = t('place_order');
    }
  };
  draw();
}

function pageTrack() {
  const form = $('#trackForm'), out = $('#result'), msg = $('#msg');
  const el = n => form.elements[n];
  const q = new URLSearchParams(location.search).get('no');
  if (q) el('order_no').value = q;
  form.onsubmit = async e => {
    e.preventDefault(); msg.className = 'msg'; out.innerHTML = '';
    try {
      const r = await rpc('track_order', { p_order_no: el('order_no').value.trim(), p_phone: el('phone').value.trim() });
      if (!r) { msg.className = 'msg err'; msg.textContent = t('track_none'); return; }
      out.innerHTML = `<div class="panel wide">
        <p>${t('order_no')}: <strong>${esc(r.order_no)}</strong></p>
        <p><span class="status ${esc(r.status)}">${t('st_' + r.status)}</span></p>
        ${(r.items || []).map(i => `<div class="cart-row"><div class="info"><strong>${esc(i.name)}</strong>
          <div class="muted">${i.qty} × ${money(i.price)}</div></div><b>${money(i.total)}</b></div>`).join('')}
        <div class="total-bar"><span>${t('total')}</span><span>${money(r.total)}</span></div></div>`;
    } catch (err) { msg.className = 'msg err'; msg.textContent = t('track_none'); }
  };
  if (q) el('phone').focus();
}

/* ---------- تشغيل ---------- */
function applyTexts() {
  document.querySelectorAll('[data-i18n]').forEach(el => el.textContent = t(el.dataset.i18n));
  document.querySelectorAll('[data-ph]').forEach(el => el.placeholder = t(el.dataset.ph));
}

async function boot() {
  const page = document.body.dataset.page;
  if (!CFG.url || CFG.url.startsWith('__')) {
    document.body.insertAdjacentHTML('afterbegin', '<p style="padding:16px;color:#c62828">config.js غير مضبوط (SUPABASE_URL / SUPABASE_ANON_KEY).</p>');
    return;
  }
  await loadShop();
  renderShell(); applyTexts();
  try {
    if (page === 'home') await pageHome();
    else if (page === 'products') await pageProducts();
    else if (page === 'categories') await pageCategories();
    else if (page === 'about') pageAbout();
    else if (page === 'contact') pageContact();
    else if (page === 'login') pageLogin();
    else if (page === 'cart') pageCart();
    else if (page === 'track') pageTrack();
  } catch (e) {
    const box = $('#content');
    if (box) box.innerHTML = `<div class="empty">${t('error')} (${esc(e.message)})</div>`;
  }
}
boot();
