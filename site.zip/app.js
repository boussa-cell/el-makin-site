/* EL MAKIN — الموقع العام. يقرأ من Supabase عبر Views عامة آمنة (بدون أسعار الشراء). */
const CFG = window.SITE_CONFIG;

const T = {
  ar: {
    home:'الرئيسية', products:'المنتجات', categories:'الأقسام', about:'من نحن', contact:'اتصل بنا', login:'دخول',
    hero_sub:'أدوات مدرسية وهدايا بالجملة والتجزئة بأفضل الأسعار.',
    browse:'تصفح المنتجات', latest:'أحدث المنتجات', all:'الكل', search:'ابحث باسم المنتج...',
    retail:'تجزئة', wholesale:'جملة', in_stock:'متوفر', out_stock:'غير متوفر', load_more:'عرض المزيد',
    no_results:'لا توجد نتائج', loading:'جارٍ التحميل...', error:'تعذر تحميل البيانات',
    about_title:'من نحن',
    about_text:'EL MAKIN محل متخصص في بيع الأدوات المدرسية والهدايا بالجملة والتجزئة. نوفر لزبائننا منتجات متنوعة بأسعار منافسة وخدمة سريعة، مع إمكانية الشحن لمختلف الولايات.',
    contact_title:'تواصل معنا', name:'الاسم', phone:'الهاتف', message:'رسالتك', send:'إرسال',
    sent:'تم إرسال رسالتك. سنتواصل معك قريبًا.', fill:'يرجى ملء الاسم والرسالة.',
    login_title:'تسجيل الدخول', email:'البريد الإلكتروني', password:'كلمة المرور', signin:'دخول', signout:'تسجيل الخروج',
    logged_in:'تم تسجيل الدخول بنجاح.', bad_login:'البريد أو كلمة المرور غير صحيحة.',
    store_soon:'حساب الزبون والطلب عبر الموقع سيتوفران قريبًا. موظفو المحل يستخدمون تطبيق EL MAKIN.',
    rights:'جميع الحقوق محفوظة', lang:'Français', address:'العنوان', tel:'الهاتف'
  },
  fr: {
    home:'Accueil', products:'Produits', categories:'Catégories', about:'À propos', contact:'Contact', login:'Connexion',
    hero_sub:'Fournitures scolaires et cadeaux en gros et au détail, aux meilleurs prix.',
    browse:'Voir les produits', latest:'Nouveautés', all:'Tout', search:'Rechercher un produit...',
    retail:'Détail', wholesale:'Gros', in_stock:'En stock', out_stock:'Rupture', load_more:'Voir plus',
    no_results:'Aucun résultat', loading:'Chargement...', error:'Impossible de charger les données',
    about_title:'À propos',
    about_text:"EL MAKIN est spécialisé dans la vente de fournitures scolaires et de cadeaux en gros et au détail. Nous proposons un large choix de produits à prix compétitifs et un service rapide, avec expédition vers toutes les wilayas.",
    contact_title:'Contactez-nous', name:'Nom', phone:'Téléphone', message:'Votre message', send:'Envoyer',
    sent:'Message envoyé. Nous vous répondrons bientôt.', fill:'Veuillez remplir le nom et le message.',
    login_title:'Connexion', email:'E-mail', password:'Mot de passe', signin:'Se connecter', signout:'Se déconnecter',
    logged_in:'Connexion réussie.', bad_login:'E-mail ou mot de passe incorrect.',
    store_soon:"Le compte client et la commande en ligne arrivent bientôt. Le personnel utilise l'application EL MAKIN.",
    rights:'Tous droits réservés', lang:'العربية', address:'Adresse', tel:'Téléphone'
  }
};

let lang = localStorage.getItem('lang') || 'ar';
const t = k => (T[lang] && T[lang][k]) || k;
const $ = (s, el = document) => el.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money = n => new Intl.NumberFormat('fr-DZ', {maximumFractionDigits: 2}).format(Number(n || 0)) + ' DZD';
const pname = p => (lang === 'fr' && p.name_fr) ? p.name_fr : p.name_ar;
const cname = c => (lang === 'fr' && c.name_fr) ? c.name_fr : c.name_ar;

let session = null;
try { session = JSON.parse(localStorage.getItem('session') || 'null'); } catch (_) {}

async function api(path, opts = {}) {
  const res = await fetch(CFG.url + path, {
    ...opts,
    headers: {
      apikey: CFG.key,
      Authorization: 'Bearer ' + ((session && session.access_token) || CFG.key),
      ...(opts.headers || {})
    }
  });
  if (!res.ok) {
    let detail = '';
    try { detail = (await res.json()).message || ''; } catch (_) {}
    throw new Error(detail || ('HTTP ' + res.status));
  }
  return res.status === 204 ? null : res.json();
}

let shop = { shop_name: 'EL MAKIN', phone: '', address: '' };
async function loadShop() {
  try {
    const rows = await api('/rest/v1/public_shop?select=key,value');
    rows.forEach(r => shop[r.key] = r.value);
  } catch (_) {}
}

const PAGES = [
  ['index.html', 'home'], ['products.html', 'products'], ['categories.html', 'categories'],
  ['about.html', 'about'], ['contact.html', 'contact'], ['login.html', 'login']
];

function renderShell() {
  const page = document.body.dataset.page;
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  $('#hdr').innerHTML = `
    <header class="site"><div class="bar">
      <a class="brand" href="index.html">EL MAKIN</a>
      <nav class="main">${PAGES.map(([f, k]) =>
        `<a href="${f}" class="${page === k ? 'active' : ''}">${t(k)}</a>`).join('')}</nav>
      <button class="lang-btn" id="langBtn">${t('lang')}</button>
    </div></header>`;
  $('#ftr').innerHTML = `
    <footer class="site"><div class="container">
      <strong>${esc(shop.shop_name || 'EL MAKIN')}</strong>
      ${shop.phone ? `<div>${t('tel')}: <a href="tel:${esc(shop.phone)}">${esc(shop.phone)}</a></div>` : ''}
      ${shop.address ? `<div>${t('address')}: ${esc(shop.address)}</div>` : ''}
      <div class="muted">© ${new Date().getFullYear()} EL MAKIN — ${t('rights')}</div>
    </div></footer>`;
  $('#langBtn').onclick = () => { lang = lang === 'ar' ? 'fr' : 'ar'; localStorage.setItem('lang', lang); boot(true); };
}

function productCard(p) {
  const img = p.image_url ? `<img loading="lazy" src="${esc(p.image_url)}" alt="">` : '🎁';
  const prices = CFG.showPrices ? `
    <div class="price">${t('retail')}: ${money(p.retail_price)}</div>
    ${Number(p.wholesale_price) > 0 ? `<div class="muted">${t('wholesale')}: ${money(p.wholesale_price)}</div>` : ''}` : '';
  return `<div class="card"><div class="img">${img}</div><div class="body">
    <h3>${esc(pname(p))}</h3>${prices}
    <span class="badge ${p.in_stock ? 'ok' : 'out'}">${p.in_stock ? t('in_stock') : t('out_stock')}</span>
  </div></div>`;
}

/* ---------- الصفحات ---------- */
async function pageHome() {
  const [cats, prods] = await Promise.all([
    api('/rest/v1/public_categories?select=*&order=name_ar.asc&limit=12'),
    api('/rest/v1/public_products?select=*&order=name_ar.asc&limit=8')
  ]);
  $('#heroSub').textContent = t('hero_sub');
  $('#heroName').textContent = shop.shop_name || 'EL MAKIN';
  $('#cats').innerHTML = cats.map(c => `<a class="chip" href="products.html?cat=${c.id}">${esc(cname(c))}</a>`).join('');
  $('#latest').innerHTML = prods.length ? prods.map(productCard).join('') : `<div class="empty">${t('no_results')}</div>`;
}

async function pageProducts() {
  const params = new URLSearchParams(location.search);
  let cat = params.get('cat') || '', q = params.get('q') || '', offset = 0;
  const cats = await api('/rest/v1/public_categories?select=*&order=name_ar.asc');
  const chips = $('#chips'), grid = $('#grid'), more = $('#more'), search = $('#search');
  search.placeholder = t('search'); search.value = q;

  const drawChips = () => {
    chips.innerHTML = `<span class="chip ${!cat ? 'active' : ''}" data-id="">${t('all')}</span>` +
      cats.map(c => `<span class="chip ${cat === c.id ? 'active' : ''}" data-id="${c.id}">${esc(cname(c))}</span>`).join('');
    chips.querySelectorAll('.chip').forEach(el => el.onclick = () => { cat = el.dataset.id; reload(); });
  };

  async function load(reset) {
    if (reset) { offset = 0; grid.innerHTML = ''; }
    let url = `/rest/v1/public_products?select=*&order=name_ar.asc&limit=${CFG.pageSize}&offset=${offset}`;
    if (cat) url += `&category_id=eq.${encodeURIComponent(cat)}`;
    const s = q.trim().replace(/[,()*%]/g, '');
    if (s) url += `&or=(name_ar.ilike.*${encodeURIComponent(s)}*,name_fr.ilike.*${encodeURIComponent(s)}*)`;
    const rows = await api(url);
    grid.insertAdjacentHTML('beforeend', rows.map(productCard).join(''));
    if (reset && !rows.length) grid.innerHTML = `<div class="empty">${t('no_results')}</div>`;
    offset += rows.length;
    more.style.display = rows.length === CFG.pageSize ? 'inline-block' : 'none';
  }
  const reload = () => { drawChips(); return load(true); };
  more.textContent = t('load_more'); more.onclick = () => load(false);
  let timer; search.oninput = () => { clearTimeout(timer); timer = setTimeout(() => { q = search.value; load(true); }, 350); };
  drawChips(); await load(true);
}

async function pageCategories() {
  const cats = await api('/rest/v1/public_categories?select=*&order=name_ar.asc');
  $('#catGrid').innerHTML = cats.length
    ? cats.map(c => `<a class="card" href="products.html?cat=${c.id}"><div class="body"><h3>📁 ${esc(cname(c))}</h3></div></a>`).join('')
    : `<div class="empty">${t('no_results')}</div>`;
}

function pageAbout() { $('#aboutText').textContent = t('about_text'); }

function pageContact() {
  const form = $('#contactForm'), msg = $('#msg');
  form.onsubmit = async e => {
    e.preventDefault();
    const name = form.elements['name'].value.trim(), phone = form.elements['phone'].value.trim(), message = form.elements['message'].value.trim();
    msg.className = 'msg';
    if (!name || !message) { msg.className = 'msg err'; msg.textContent = t('fill'); return; }
    try {
      await api('/rest/v1/contact_messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Prefer: 'return=minimal' },
        body: JSON.stringify({ name, phone: phone || null, message })
      });
      form.reset(); msg.className = 'msg ok'; msg.textContent = t('sent');
    } catch (err) { msg.className = 'msg err'; msg.textContent = t('error'); }
  };
}

function pageLogin() {
  const form = $('#loginForm'), msg = $('#msg'), out = $('#signedIn');
  const draw = () => {
    form.style.display = session ? 'none' : 'block';
    out.style.display = session ? 'block' : 'none';
    if (session) $('#who').textContent = (session.user && session.user.email) || '';
  };
  form.onsubmit = async e => {
    e.preventDefault(); msg.className = 'msg';
    try {
      const res = await fetch(CFG.url + '/auth/v1/token?grant_type=password', {
        method: 'POST',
        headers: { apikey: CFG.key, 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: form.elements['email'].value.trim(), password: form.elements['password'].value })
      });
      if (!res.ok) throw new Error('bad');
      session = await res.json();
      localStorage.setItem('session', JSON.stringify(session));
      msg.className = 'msg ok'; msg.textContent = t('logged_in'); draw();
    } catch (_) { msg.className = 'msg err'; msg.textContent = t('bad_login'); }
  };
  $('#signout').onclick = () => { session = null; localStorage.removeItem('session'); msg.className = 'msg'; draw(); };
  draw();
}

/* ---------- تشغيل ---------- */
function applyTexts() {
  document.querySelectorAll('[data-i18n]').forEach(el => el.textContent = t(el.dataset.i18n));
  document.querySelectorAll('[data-ph]').forEach(el => el.placeholder = t(el.dataset.ph));
}

async function boot() {
  const page = document.body.dataset.page;
  if (!CFG.url || CFG.url.startsWith('__')) {
    document.body.insertAdjacentHTML('afterbegin', '<p style="padding:16px;color:#c62828">config.js غير مضبوط (SUPABASE_URL / SUPABASE_ANON_KEY).</p>');
    return;
  }
  await loadShop();
  renderShell(); applyTexts();
  try {
    if (page === 'home') await pageHome();
    else if (page === 'products') await pageProducts();
    else if (page === 'categories') await pageCategories();
    else if (page === 'about') pageAbout();
    else if (page === 'contact') pageContact();
    else if (page === 'login') pageLogin();
  } catch (e) {
    const box = $('#content');
    if (box) box.innerHTML = `<div class="empty">${t('error')}</div>`;
  }
}
boot();
